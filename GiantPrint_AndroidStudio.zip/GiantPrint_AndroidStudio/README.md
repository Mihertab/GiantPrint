# GiantPrint – Android Studio project

A native Kotlin Android starter app for the Canon imageRUNNER ADVANCE iR2425i.

## Features
- Save printer IPv4 address locally on the phone.
- Scan QR codes and extract an IPv4 address when present.
- Pick PDF documents and images using Android's document picker.
- Send PDFs and images to Android's print framework.
- Choose the Canon printer through an installed Mopria/Canon-compatible print service.

## Open in Android Studio
1. Extract `GiantPrint_AndroidStudio.zip`.
2. In Android Studio choose **Open** and select the extracted `GiantPrint_AndroidStudio` folder.
3. Allow Gradle sync. Use JDK 17.
4. If Android Studio offers to install Android SDK Platform 35, accept.
5. Connect your Android phone with USB debugging enabled, or use an emulator.
6. Press Run.

This project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. Android Studio may offer a compatible Gradle distribution during import.

## Printer setup
1. Connect the Canon iR2425i and phone to the same Wi-Fi network.
2. Enable Mopria on the printer, if available in its administrator settings.
3. Enable an Android print service such as Default Print Service or Mopria Print Service on the phone.
4. Find the printer's IP address on the printer network settings page and save it in GiantPrint.
5. Select a PDF or image, tap Continue to Android Printing, then select the Canon printer.

## Important technical notes
- The saved IP is a convenience/reference value. Android's print framework performs printer discovery and print delivery; this app does not send raw IPP/9100 print jobs itself.
- A scanned QR code is only auto-used if its text contains a valid IPv4 address. Canon QR payloads can contain other pairing/configuration data, so inspect unrecognized QR content before relying on it.
- The app uses Android's document picker and print framework. Actual printer availability depends on the installed print service, printer firmware/configuration, Wi-Fi network and phone.
- The eagle icon in this starter project is a placeholder. Replace it with your own supplied GiantPrint eagle-and-wave logo at a later stage. The previous uploaded logo is not embedded in this package because it is not available as a file in this project-generation step.
- This is a complete source project, not a signed APK. Build an APK from Android Studio using Build > Build Bundle(s) / APK(s) > Build APK(s).
