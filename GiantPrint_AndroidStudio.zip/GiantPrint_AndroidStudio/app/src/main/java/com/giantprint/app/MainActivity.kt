package com.giantprint.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PageRange
import android.print.PrintManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.print.PrintHelper
import com.google.zxing.integration.android.IntentIntegrator
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var printerIpInput: EditText
    private lateinit var statusText: TextView
    private lateinit var selectedFileText: TextView
    private lateinit var saveIpButton: Button
    private lateinit var scanButton: Button
    private lateinit var pdfButton: Button
    private lateinit var imageButton: Button
    private lateinit var printButton: Button

    private var selectedUri: Uri? = null
    private var selectedMimeType: String? = null
    private val preferences by lazy { getSharedPreferences("giantprint_settings", Context.MODE_PRIVATE) }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            onDocumentSelected(uri, "application/pdf")
        }
    }

    private val imagePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            onDocumentSelected(uri, "image/*")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        printerIpInput.setText(preferences.getString("printer_ip", ""))
        updateStatus(if (printerIpInput.text.isNullOrBlank()) {
            "Ready. Add your printer IP address or scan its QR code."
        } else {
            "Printer address saved. Make sure your phone and printer use the same Wi-Fi."
        })
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(245, 248, 252))
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "🦅"
            textSize = 42f
            gravity = Gravity.CENTER
        }
        page.addView(brand, matchWrap())

        val title = TextView(this).apply {
            text = "GiantPrint"
            textSize = 30f
            setTextColor(Color.rgb(20, 93, 160))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "SMART WI-FI PRINTING"
            textSize = 12f
            letterSpacing = 0.16f
            setTextColor(Color.rgb(92, 108, 126))
            gravity = Gravity.CENTER
        }
        page.addView(subtitle, matchWrap())
        addSpace(page, 22)

        sectionLabel(page, "PRINTER CONNECTION")
        printerIpInput = EditText(this).apply {
            hint = "Printer IP address (example: 192.168.1.50)"
            textSize = 15f
            singleLine = true
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, Color.rgb(215, 225, 237))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        page.addView(printerIpInput, matchWidth(dp(54)))
        addSpace(page, 10)

        saveIpButton = makeButton("Save Printer Address", primary = true)
        page.addView(saveIpButton, matchWidth(dp(52)))
        saveIpButton.setOnClickListener { savePrinterIp() }

        scanButton = makeButton("Scan Printer QR Code", primary = false)
        page.addView(scanButton, matchWidth(dp(52)))
        scanButton.setOnClickListener { startQrScanner() }
        addSpace(page, 18)

        sectionLabel(page, "CHOOSE A DOCUMENT")
        pdfButton = makeButton("Select PDF Document", primary = false)
        page.addView(pdfButton, matchWidth(dp(52)))
        pdfButton.setOnClickListener { pdfPicker.launch(arrayOf("application/pdf")) }

        imageButton = makeButton("Select Image", primary = false)
        page.addView(imageButton, matchWidth(dp(52)))
        imageButton.setOnClickListener { imagePicker.launch(arrayOf("image/*")) }

        selectedFileText = TextView(this).apply {
            text = "No document selected"
            textSize = 13f
            setTextColor(Color.rgb(92, 108, 126))
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        page.addView(selectedFileText, matchWrap())
        addSpace(page, 8)

        printButton = makeButton("Continue to Android Printing", primary = true)
        page.addView(printButton, matchWidth(dp(56)))
        printButton.setOnClickListener { printSelectedDocument() }
        addSpace(page, 20)

        sectionLabel(page, "APP STATUS")
        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(40, 65, 88))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(232, 241, 250), Color.rgb(207, 224, 241))
        }
        page.addView(statusText, matchWidth(ViewGroup.LayoutParams.WRAP_CONTENT))

        addSpace(page, 18)
        val note = TextView(this).apply {
            text = "GiantPrint uses Android's print system. Select your Canon iR2425i in the print screen. Your phone and printer must be on the same Wi-Fi network."
            textSize = 12f
            setTextColor(Color.rgb(105, 117, 130))
            gravity = Gravity.CENTER
        }
        page.addView(note, matchWrap())
    }

    private fun savePrinterIp() {
        val ip = printerIpInput.text.toString().trim()
        if (!isValidIpv4(ip)) {
            toast("Enter a valid IPv4 address, for example 192.168.1.50")
            return
        }
        preferences.edit().putString("printer_ip", ip).apply()
        updateStatus("Printer address saved: $ip")
        toast("Printer address saved")
    }

    private fun startQrScanner() {
        try {
            val integrator = IntentIntegrator(this)
            integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
            integrator.setPrompt("Scan the Canon printer QR code")
            integrator.setBeepEnabled(true)
            integrator.setOrientationLocked(false)
            integrator.initiateScan()
        } catch (e: Exception) {
            toast("Could not start QR scanner: ${e.localizedMessage ?: "unknown error"}")
        }
    }

    @Deprecated("The scanner library returns its result through this callback.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            val contents = result.contents
            if (contents.isNullOrBlank()) {
                updateStatus("QR scan cancelled.")
            } else {
                val foundIp = extractIpv4(contents)
                if (foundIp != null) {
                    printerIpInput.setText(foundIp)
                    preferences.edit().putString("printer_ip", foundIp).apply()
                    updateStatus("Printer IP found and saved: $foundIp")
                    toast("Printer IP saved")
                } else {
                    updateStatus("QR scanned, but it did not contain a recognizable IPv4 address. Check the QR details or enter the IP manually.")
                    android.app.AlertDialog.Builder(this)
                        .setTitle("QR code contents")
                        .setMessage(contents)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun onDocumentSelected(uri: Uri, mimeType: String) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Some document providers do not offer persistable permissions.
        }
        selectedUri = uri
        selectedMimeType = mimeType
        selectedFileText.text = "Selected: ${uri.lastPathSegment ?: uri.toString()}"
        updateStatus("Document selected. Tap Continue to Android Printing.")
    }

    private fun printSelectedDocument() {
        val uri = selectedUri
        val mime = selectedMimeType
        if (uri == null || mime == null) {
            toast("Select a PDF or image first")
            return
        }
        try {
            if (mime == "application/pdf") {
                printPdf(uri)
            } else {
                val helper = PrintHelper(this)
                helper.scaleMode = PrintHelper.SCALE_MODE_FIT
                helper.colorMode = PrintHelper.COLOR_MODE_COLOR
                helper.printBitmap("GiantPrint image", uri)
            }
        } catch (e: Exception) {
            updateStatus("Could not open print screen: ${e.localizedMessage ?: "unknown error"}")
            toast("Printing could not start")
        }
    }

    private fun printPdf(uri: Uri) {
        val printManager = getSystemService(PRINT_SERVICE) as PrintManager
        val jobName = "GiantPrint PDF"
        printManager.print(
            jobName,
            PdfUriPrintAdapter(contentResolver, uri, jobName),
            PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(PrintAttributes.Resolution("giantprint", "GiantPrint", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build()
        )
        updateStatus("Android print screen opened. Choose Canon iR2425i.")
    }

    private fun isValidIpv4(value: String): Boolean {
        val parts = value.split(".")
        if (parts.size != 4) return false
        return parts.all {
            val number = it.toIntOrNull()
            number != null && number in 0..255 && it.isNotEmpty()
        }
    }

    private fun extractIpv4(text: String): String? {
        val regex = Regex("""(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)""")
        return regex.find(text)?.value?.takeIf { isValidIpv4(it) }
    }

    private fun updateStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun sectionLabel(parent: LinearLayout, label: String) {
        val view = TextView(this).apply {
            text = label
            textSize = 12f
            letterSpacing = 0.08f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(82, 101, 122))
            setPadding(2, dp(4), 2, dp(8))
        }
        parent.addView(view, matchWrap())
    }

    private fun makeButton(label: String, primary: Boolean): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (primary) Color.WHITE else Color.rgb(20, 93, 160))
            background = rounded(
                if (primary) Color.rgb(20, 93, 160) else Color.WHITE,
                if (primary) Color.rgb(20, 93, 160) else Color.rgb(203, 219, 235)
            )
            stateListAnimator = null
        }
    }

    private fun rounded(fill: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(13).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun matchWidth(height: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        height
    ).apply {
        bottomMargin = dp(8)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

private class PdfUriPrintAdapter(
    private val resolver: android.content.ContentResolver,
    private val sourceUri: Uri,
    private val jobName: String
) : PrintDocumentAdapter() {

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: android.os.CancellationSignal?,
        callback: LayoutResultCallback?,
        extras: android.os.Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback?.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder(jobName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback?.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor?,
        cancellationSignal: android.os.CancellationSignal?,
        callback: WriteResultCallback?
    ) {
        if (destination == null) {
            callback?.onWriteFailed("Print destination unavailable")
            return
        }
        try {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onWriteCancelled()
                return
            }
            resolver.openInputStream(sourceUri).use { input ->
                if (input == null) {
                    callback?.onWriteFailed("Cannot read selected PDF")
                    return
                }
                FileOutputStream(destination.fileDescriptor).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback?.onWriteFailed(e.localizedMessage ?: "Unable to prepare PDF")
        } finally {
            try { destination.close() } catch (_: Exception) {}
        }
    }
}
